function [FinalPath,IndvidualCoverages]=To_CombinePath(FinalPath1,FinalPath2,AllSpe,NumSpe,m,n)
FinalPath=[]; IndvidualCoverages=[];
[m1,~]=size(FinalPath1);
[m2,~]=size(FinalPath2);
for i=1:m1
       for j=1:m2
        JoinedPath=[FinalPath1(i,:),FinalPath2(j,:)];
        %FinalPath=[FinalPath;JoinedPath];
        [ExtraCoverage,Individual]=Get_Rank(AllSpe,NumSpe,JoinedPath,m,n);
        FinalPath=[FinalPath;JoinedPath, ExtraCoverage];
        IndvidualCoverages=[IndvidualCoverages;Individual];
       end
end
