function [BestPath,AdditionalC]=Get_BestPath(AllConnectors)
[~,col]=size(AllConnectors);
 AllConnectors=sortrows(AllConnectors,-col) ; % Last col contains the total exatra coverage.
 BestPath=AllConnectors(1,1:end-1); % best path containg the max species, the first two elemnets for the clus1 and clus2
 AdditionalC=AllConnectors(1,end); % best additional coverage