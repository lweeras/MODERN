function [Connecter1,Connecter2]=get_connectors(clus1,clus2,CL1cell,CL2cell,NumClu,Label,Successor1,Successor2,Connecter1,Connecter2)
[L1,~]= size(Successor1);
[L2,~]= size(Successor2);
Cell1=CL1cell;
Cell2=CL2cell;
for p=Label-2:-1:1 %To find the connection
    p;
    %LevelLength=LevelSize(:,:,p);
    CurrentList1=[];CurrentList2=[];
    for q=1: NumClu
        for i=1:L1 % For Clus 1
            Label1=Successor1(i,:);
            if (q==clus1 && Label1(4)==p )
                CurrentList1=[CurrentList1;Label1];
            end
        end
        for i=1:L2 % For Clus 2
            Label2=Successor2(i,:);
            if (q==clus2 && Label2(4)==p )
                CurrentList2=[CurrentList2;Label2];
            end
        end
        
    end
%end
if (Cell1(4)~=1)
    [CL1cell] = get_BDCellForPath1(CurrentList1,Cell1);
    
end
if (Cell2(4)~=1)
    CurrentList2;
    Cell2;
    [CL2cell] = get_BDCellForPath2(CurrentList2,Cell2);
end
%[CL1cell,CL2cell] = get_BDCellForPath(CurrentList1,CurrentList2,Cell1,Cell2);
[NumAdj1,~]=size(CL1cell);
[NumAdj2,~]=size(CL2cell);

if (NumAdj1~=0)
    %OldMultiData(CL1cell(1),CL1cell(2),clus1)=1;
    %CL1cell(1:2);
    Connecter1=[Connecter1;CL1cell(1:2)];
    Cell1=CL1cell;
else
    Cell1=zeros(1,4);
end
length(CL2cell);
if (NumAdj2~=0)
    %OldMultiData(CL2cell(1),CL2cell(2),clus2)=1;
    %CL2cell;
    Connecter2=[Connecter2;CL2cell(1:2)];
    Cell2=CL2cell;
else
    Cell2=zeros(1,4);
end
end
