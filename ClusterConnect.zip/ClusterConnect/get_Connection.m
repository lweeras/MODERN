function [BC, BSite] = get_Connection(Cl1,Cl2,m,n,Label,k,NumClu)
Connection=Cl1;
BC=[]; Predecessors=[]; Rank=[];
while (NumClu>1)
    SubPredecessors=[];
    for i=2:m-1
        for j=2:n-1
            if (Cl1(i,j)>0)
                if (Cl1(i,j+1)==0 )
                    Connection(i,j+1)=Label; % Visited
                    BC=[BC;[i,j+1,k,Label]];
                    SubPredecessors=[SubPredecessors;i,j, i,j+1,Label];
                end
                if (Cl1(i,j-1)==0 )
                    Connection(i,j-1)=Label;
                    BC=[BC;[i,j-1,k,Label]];
                    SubPredecessors=[SubPredecessors;i,j,i,j-1,Label];
                end
                if (Cl1(i+1,j)==0 )
                    Connection(i+1,j)=Label;
                    BC=[BC;[i+1,j,k, Label]];
                    SubPredecessors=[SubPredecessors;i,j,i+1,j,Label];
                end
                
                if (Cl1(i-1,j)==0 )
                    Connection(i-1,j)=Label;
                    BC=[BC;[i-1,j,k,Label]];
                    SubPredecessors=[SubPredecessors;i,j,i-1,j,Label];
                end
            end
        end
    end
    SubPredecessors
    Rank=[Rank,length(SubPredecessors)]
    Predecessors=[Predecessors;SubPredecessors]
    Connection
    Cl1=Connection
    BC
    
    for r=1:length(BC)
        BSite=[BC(r,1:2)];
        for p=2:m-1
            for q=2:n-1
                if (Cl2(p,q)>0 && p==BSite(1) && q ==BSite(2))
                    disp('two clusters are merged')
                    BSite
                    NumClu=NumClu-1;
                   
                end

            end
        end
    end
    Label=Label+1;
end
Rank
Label
TotalBdSites=sum(Rank)
for k=Label:-1:1
    BlockSize=TotalBdSites-sum(Rank(1:k-2))
    Block=Predecessors(TotalBdSites:-1:(TotalBdSites-BlockSize+1),:)
% for i=2:n-1
%     for j=2:m-1
%         if ((Connection(i)==BSite(i)) && (Connection(j)==BSite(j)))
%             'hello'
%         end
%     end
% end
end
dlmwrite('C:\CompactConnect2020\Connection.txt',BC,'delimiter','\t');
SubPredecessors

