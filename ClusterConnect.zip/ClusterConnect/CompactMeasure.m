clc
clear
Data=load('data.txt');
% Cl1=load('cluster1.txt')
% Cl2=load('cluster2.txt');
% Cl3=load('cluster3.txt');
% clusterData=load('clusterData.txt');
% s1=load('s1.txt');
% s2=load('s2.txt');
% s3=load('s3.txt');
[m,n]=size(Data);
commonedges=0; BL=0;
for i=1:m-1
    for j=1:n-1
        if (Data(i,j)==1)
            if (Data(i,j+1)==1)
                commonedges=commonedges+1;
            end
            if (Data(i,j-1)==1)
                commonedges=commonedges+1;
            end
            if (Data(i+1,j)==1)
                commonedges=commonedges+1;
            end
            if (Data(i-1,j)==1)
                commonedges=commonedges+1;
            end
        end
    end
end

for i=1:m-1
    for j=1:n-1
        if (Data(i,j)==1)
            if (Data(i,j+1)==0)
                BL=BL+1;
            end
            if (Data(i,j-1)==0)
                BL=BL+1;
            end
            if (Data(i+1,j)==0)
                BL=BL+1;
            end
            if (Data(i-1,j)==0)
                BL=BL+1;
            end
        end
    end
end
edges=commonedges/2
BL
Ratio=edges/sum(sum(Data))
Q=(4*pi*sum(sum(Data)))/(BL^2)
X=[sum(sum(Data)),edges,Ratio,BL,Q]
dlmwrite('Output.txt', X,'delimiter','\t');
% sum1=0; sum2=0;
% sum3=0;
% for i=1:m
%     for j=1:n
%         if(s1(i,j)==1 && Data(i,j)==1)
%             sum1=sum1+1;
%         end
%         if(s2(i,j)==1 && Data(i,j)==1)
%             sum2=sum2+1;
%         end
%         if(s3(i,j)==1 && Data(i,j)==1)
%             sum3=sum3+1;
%         end
%     end
% end
% Connection=clusterData;
% UpdatedCluster=clusterData;
% [m,n]=size(clusterData);
% MergedCluster=zeros(n,m);
% M=100;
% for i=1:m
%     for j=1:n
%         if(clusterData(i,j)~=0)
%             MergedCluster(i,j)=M;
%             
%         end
%     end
% end
% NumClu=2;
% Connection=Cl1
% Label=1
% k=1;
% BC=[];
% while (NumClu~=1)
%     for i=2:m-1
%         for j=2:n-1
%             if (Cl1(i,j)>0)
%                 if (Cl1(i,j+1)==0 )
%                     Connection(i,j+1)=Label; % Visited
%                     BC=[BC;[i,j+1,k,Label]];
%                 end
%                 if (Cl1(i,j-1)==0 )
%                     Connection(i,j-1)=Label;
%                     BC=[BC;[i,j-1,k,Label]];
%                 end
%                 if (Cl1(i+1,j)==0 )
%                     Connection(i+1,j)=Label;
%                     BC=[BC;[i+1,j,k,Label]];
%                 end
%                 
%                 if (Cl1(i-1,j)==0 )
%                     Connection(i-1,j)=Label;
%                     BC=[BC;[i-1,j,k,Label]];
%                 end
%             end
%         end
%     end
%     Connection
%     Cl1=Connection
%     BC
%     Label=Label+1;
%     for r=1:length(BC)
%         BSite=[BC(r,1:2)];
%         for p=2:m-1
%             for q=2:n-1
%                 if (Cl2(p,q)>0 && p==BSite(1) && q ==BSite(2))
%                     disp('merged 1 and 2')
%                     BSite
%                     NumClu=NumClu-1;
%                     break
%                 end
% 
%             end
%         end
%     end
% end
% 
% dlmwrite('C:\CompactConnect2020\Connection.txt',Connection,'delimiter','\t');

% NumClu=2;
% Cl1=Cl2;
% Connection=Cl2
% Label=1
% k=2;
% BC=[];
% while (NumClu~=1)
%     for i=2:m-1
%         for j=2:n-1
%             if (Cl1(i,j)>0)
%                 if (Cl1(i,j+1)==0 )
%                     Connection(i,j+1)=Label; % Visited
%                     BC=[BC;[i,j+1,k,Label]];
%                 end
%                 if (Cl1(i,j-1)==0 )
%                     Connection(i,j-1)=Label;
%                     BC=[BC;[i,j-1,k,Label]];
%                 end
%                 if (Cl1(i+1,j)==0 )
%                     Connection(i+1,j)=Label;
%                     BC=[BC;[i+1,j,k,Label]];
%                 end
%                 if (Cl1(i-1,j)==0 )
%                     Connection(i-1,j)=Label;
%                     BC=[BC;[i-1,j,k,Label]];
%                 end
%             end
%         end
%     end
%     Connection
%     Cl1=Connection
%     BC
%     Label=Label+1
%     for r=1:length(BC)
%         BSite=[BC(r,1:2)];
%         for p=2:m-1
%             for q=2:n-1
%                 if (Cl3(p,q)>0 && p==BSite(1) && q ==BSite(2))
%                     disp('two clusters are merged')
%                     BSite
%                     NumClu=NumClu-1;
%                     break
%                 end
%             end
%         end
%     end
% end
