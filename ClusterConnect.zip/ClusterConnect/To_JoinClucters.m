%function [clus1,clus2,AllList,CL1cell,CL2cel2,LevelSize,Label] = get_OneClucter(Data, m,n,Label,NumClu)
function [clus1,clus2,AllList,CL1cell,CL2cel2,LevelSize,Label] = To_JoinClucters(MultiData, m,n,Label,NumClu)
BC=[]; Predecessors=[]; Rank=[];AllList=[]; LevelSize=[];
Connection=MultiData;
True=0;
while ( True==0)
    SubPredecessors=[];
    SizeList=[];
    for k=1:NumClu
        CurrentClu= MultiData(:,:,k) ;
        for i=1:m
            for j=1:n
                
                
                if (CurrentClu(i,j)>0)
                    if (j~=m)
                        if (CurrentClu(i,j+1)==0 )
                            Connection(i,j+1,k)=Label; % Visited
                            BC=[BC;[i,j+1,k,Label]];
                            SubPredecessors=[SubPredecessors;i,j, i,j+1,Label];
                        end
                    end
                    if (j~=1)
                        if (CurrentClu(i,j-1)==0 )
                            Connection(i,j-1,k)=Label;
                            BC=[BC;[i,j-1,k,Label]];
                            SubPredecessors=[SubPredecessors;i,j,i,j-1,Label];
                        end
                    end
                    if(i~=m)
                        if (CurrentClu(i+1,j)==0 )
                            Connection(i+1,j,k)=Label;
                            BC=[BC;[i+1,j,k, Label]];
                            SubPredecessors=[SubPredecessors;i,j,i+1,j,Label];
                        end
                    end
                    if(i~=1)
                        if (CurrentClu(i-1,j)==0 )
                            Connection(i-1,j,k)=Label;
                            BC=[BC;[i-1,j,k,Label]];
                            SubPredecessors=[SubPredecessors;i,j,i-1,j,Label];
                        end
                    end
                end
            end
        end
        BC;
        [~, iA] = uniquetol(BC, 'byrows', true);
        BC=BC(sort(iA), :);
        [L1,~]=size(BC);
        SizeList=[SizeList,L1];
    end % End of expanding levels for each cluster
    Connection;
    LevelSize(:,:,Label)=SizeList;
    SizeList;
    BC;
    
    AllList=[AllList;BC]
    SizeList
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for p=1:NumClu % checking Level k and k+1
        % 'check for label'
        Label;
        % 'P val' ;
        p;
        if (p==1)
            List1 =BC(1:SizeList(p),:);
        else
            List1=BC(SizeList(p-1)+1:SizeList(p),:);
        end
        [L2,~]=size(AllList);
        for q=1: NumClu
            if (q>p)
                % % 'Q val'
                %   q
                PreviousLevel=[];
                for r=1:(L2-L1)% Previous Levels
                    currentrow=AllList(r,:);
                    if ((currentrow(4)==Label-1) && currentrow(3)==q &&Label>1 )
                        PreviousLevel=[PreviousLevel;currentrow];
                    end
                end
                List1;
                % 'PreviousLevel';
                PreviousLevel;
                List2=PreviousLevel;
                [True,CL1cell,CL2cel2] = get_CompareList(List1,List2,m,n);
                True;
                if (True==1)
                    clus1=List1(1,3);
                    clus2=List2(1,3);
                    % 'connection';
                    CL1cell;
                    CL2cel2;
                    break
                end
                if (True==1)
                    break
                end
            end
            
        end
        if (True==1)
            break
        end
        if (Label>1)
            for q=1: NumClu % checking Level k and k
                if (q>p)
                    if (q==1)
                        List2 =BC(1:SizeList(q),:);
                    else
                        List2=BC(SizeList(q-1)+1:SizeList(q),:);
                    end
                    List1;
                    List2;
                    [True,CL1cell,CL2cel2] = get_CompareList(List1,List2,m,n);
                    True;
                    if (True==1)
                        clus1=List1(1,3);
                        clus2=List2(1,3);
                        %  'connection';
                        CL1cell;
                        CL2cel2;
                        break
                    end
                    if (True==1)
                        break
                    end
                end
                
            end
        end
        if (True==1)
            break
        end
    end
    
    
    MultiData=Connection;
    Label=Label+1;
    BC=[];
    if (True==1)
        break
    end
end
LevelSize;
