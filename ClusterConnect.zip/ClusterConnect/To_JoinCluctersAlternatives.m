%function [clus1,clus2,AllList,CL1cell,CL2cel2,LevelSize,Label] = get_OneClucter(Data, m,n,Label,NumClu)
function [AlterPath,AllList,LevelSize,Label] = To_JoinCluctersAlternatives(MultiData, m,n,Label,NumClu)
BC=[]; Predecessors=[]; Rank=[];AllList=[]; LevelSize=[];
Connection=MultiData;
True1=0;
True2=0;
AlterPath=[];
while ( True1+True2==0)
    SubPredecessors=[];
    SizeList=[];
    for k=1:NumClu
        CurrentClu= MultiData(:,:,k) ;
        for i=1:m
            for j=1:n
                
                
                if (CurrentClu(i,j)>0)
                    if (j~=m)
                        if (CurrentClu(i,j+1)==0 )
                            Connection(i,j+1,k)=Label; % Visited
                            BC=[BC;[i,j+1,k,Label]];
                            SubPredecessors=[SubPredecessors;i,j, i,j+1,Label];
                        end
                    end
                    if (j~=1)
                        if (CurrentClu(i,j-1)==0 )
                            Connection(i,j-1,k)=Label;
                            BC=[BC;[i,j-1,k,Label]];
                            SubPredecessors=[SubPredecessors;i,j,i,j-1,Label];
                        end
                    end
                    if(i~=m)
                        if (CurrentClu(i+1,j)==0 )
                            Connection(i+1,j,k)=Label;
                            BC=[BC;[i+1,j,k, Label]];
                            SubPredecessors=[SubPredecessors;i,j,i+1,j,Label];
                        end
                    end
                    if(i~=1)
                        if (CurrentClu(i-1,j)==0 )
                            Connection(i-1,j,k)=Label;
                            BC=[BC;[i-1,j,k,Label]];
                            SubPredecessors=[SubPredecessors;i,j,i-1,j,Label];
                        end
                    end
                end
            end
        end
        BC;
        [~, iA] = uniquetol(BC, 'byrows', true);
        BC=BC(sort(iA), :);
        [L1,~]=size(BC);
        SizeList=[SizeList,L1];
    end % End of expanding levels for each cluster
    
    Connection;
    LevelSize(:,:,Label)=SizeList;
    SizeList;
    BC;
    
    AllList=[AllList;BC];
    SizeList;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for p=1:NumClu % checking Level k and k+1
        % 'check for label'
        Label;
        % 'P val' ;
        p;
        if (p==1)
            List1 =BC(1:SizeList(p),:);
        else
            List1=BC(SizeList(p-1)+1:SizeList(p),:);
        end
        [L2,~]=size(AllList);
        for q=1: NumClu
            if (q>p)
                PreviousLevel=[];
                for r=1:(L2-L1)% Previous Levels
                    currentrow=AllList(r,:);
                    if ((currentrow(4)==Label-1) && currentrow(3)==q )
                        PreviousLevel=[PreviousLevel;currentrow];
                    end
                end
                
                % 'PreviousLevel';
                PreviousLevel;
                List2=PreviousLevel;
                List1;
                List2;
                [True1,Alternatives] = get_CompareListAlternative(List1,List2,m,n);
                AlterPath=[AlterPath;Alternatives];
                True1;
            end
            if(True1==1)
                break
            end
        end
        for q=1: NumClu % checking Level k and k
            if (q>p)
                if (q==1)
                    List2 =BC(1:SizeList(q),:);
                else
                    List2=BC(SizeList(q-1)+1:SizeList(q),:);
                end
                List1;
                List2;
                [True2,Alternatives] = get_CompareListAlternative(List1,List2,m,n);
                True2;
                AlterPath=[AlterPath;Alternatives];
                
            end
            if(True2==1)
                break
            end
        end
        
        if (True1+True2>=1)
            break
        end
    end
    MultiData=Connection;
    Label=Label+1;
    BC=[];
    if (True1+True2>=1)
        break
    end
end
LevelSize;
