function Connected = get_numEdges(Data,m,n)
BL=0;
for i=1:m
    for j=1:n
        if (Data(i,j)>=1)
            if(j<n)
                if (Data(i,j+1)==1)
                    BL=BL+1;
                  %  BDCells(i,j)=1;
                end
            end
            if(j>1)
                if (Data(i,j-1)==1)
                    BL=BL+1;
                  %  BDCells(i,j)=1;
                end
            end
            if(i<m)
                if (Data(i+1,j)==1)
                    BL=BL+1;
                  %  BDCells(i,j)=1;
                end
            end
            if(i>1)
                if (Data(i-1,j)==1)
                    BL=BL+1;
                   % BDCells(i,j)=1;
                end
            end
        end
    end
end
numEdges=BL;
numnodes=sum(sum(Data))
Connected=0;
if (numEdges/2==numnodes-1)
    Connected=1;
end
numEdges/2

