function [ SizeList,BC,L1] = To_ExpandClusters(MultiData, m,n,Label,NumClu)
BC=[];    SubPredecessors=[];
    SizeList=[];
    for k=1:NumClu
        CurrentClu= MultiData(:,:,k) ;
        for i=1:m
            for j=1:n
                
                
                if (CurrentClu(i,j)>0)
                    if (j~=m)
                        if (CurrentClu(i,j+1)==0 )
                            Connection(i,j+1,k)=Label; % Visited
                            BC=[BC;[i,j+1,k,Label]];
                            SubPredecessors=[SubPredecessors;i,j, i,j+1,Label];
                        end
                    end
                    if (j~=1)
                        if (CurrentClu(i,j-1)==0 )
                            Connection(i,j-1,k)=Label;
                            BC=[BC;[i,j-1,k,Label]];
                            SubPredecessors=[SubPredecessors;i,j,i,j-1,Label];
                        end
                    end
                    if(i~=m)
                        if (CurrentClu(i+1,j)==0 )
                            Connection(i+1,j,k)=Label;
                            BC=[BC;[i+1,j,k, Label]];
                            SubPredecessors=[SubPredecessors;i,j,i+1,j,Label];
                        end
                    end
                    if(i~=1)
                        if (CurrentClu(i-1,j)==0 )
                            Connection(i-1,j,k)=Label;
                            BC=[BC;[i-1,j,k,Label]];
                            SubPredecessors=[SubPredecessors;i,j,i-1,j,Label];
                        end
                    end
                end
            end
        end
        BC;
        [~, iA] = uniquetol(BC, 'byrows', true);
        BC=BC(sort(iA), :);
        [L1,~]=size(BC);
        SizeList=[SizeList,L1];
    end % End of expanding levels for each cluster