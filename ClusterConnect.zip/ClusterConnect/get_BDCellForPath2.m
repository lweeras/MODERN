function [CL2cell] = get_BDCellForPath2(List2,Cell2)
CL2cell=[];
[n,~]=size(List2);
%'Now check'
%Cell2
LN2=[Cell2(1),Cell2(2)-1];RN2=[Cell2(1),Cell2(2)+1];
TN2=[Cell2(1)-1,Cell2(2)];BN2=[Cell2(1)+1,Cell2(2)];

% if (sum(Cell2)~=0)
% for i=1:n
%     if ((List2(i,1)==LN2(1) && List2(i,2)==LN2(2)))
%         True1=1;
%         CL2cell=List2(i,:);
%         break
%     end
%     if ((List2(i,1)==RN2(1) && List2(i,2)==RN2(2)))
%         True1=1;
%         CL2cell=List2(i,:);
%         break
%     end
%     if ((List2(i,1)==TN2(1) && List2(i,2)==TN2(2)))
%         True1=1;
%         CL2cell=List2(i,:);
%         break
%     end
%     if ((List2(i,1)==BN2(1) && List2(i,2)==BN2(2)))
%         True1=1;
%         CL2cell=List2(i,:);
%         break
%     end
% end
% end
if (sum(Cell2)~=0)
for i=1:n
    if ((List2(i,1)==LN2(1) && List2(i,2)==LN2(2)))
        True1=1;
        CL2cell=[CL2cell;List2(i,:)];
        %break
    end
    if ((List2(i,1)==RN2(1) && List2(i,2)==RN2(2)))
        True1=1;
        CL2cell=[CL2cell;List2(i,:)];
        %break
    end
    if ((List2(i,1)==TN2(1) && List2(i,2)==TN2(2)))
        True1=1;
        CL2cell=[CL2cell;List2(i,:)];
        %break
    end
    if ((List2(i,1)==BN2(1) && List2(i,2)==BN2(2)))
        True1=1;
        CL2cell=[CL2cell;List2(i,:)];
        %break
    end
end
end