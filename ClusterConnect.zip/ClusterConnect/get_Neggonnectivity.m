
function const = get_Neggonnectivity(FinalCluster,m,n,row,col)
True=0;
%%%%%%%%%%%%%Corner points%%%%%%%%%%%%%%%%%%%%
if (row==1 && col==1)
    if ((FinalCluster(row,col+1)==1) || (FinalCluster(row+1,col)==1))
        if (FinalCluster(row+1,col+1)==1)
            True=1;
        end
    end
end


if (row==1 && col==n)
    if ((FinalCluster(row,col-1)==1) || (FinalCluster(row+1,col)==1))
        if (FinalCluster(row+1,col-1)==1)
            True=1;
        end
    end
end

if (row==m && col==1)
    if ((FinalCluster(row-1,col)==1) || (FinalCluster(row,col+1)==1))
        if (FinalCluster(row-1,col+1)==1)
            True=1;
        end
    end
end


if (row==m && col==n)
    if ((FinalCluster(row-1,col)==1) || (FinalCluster(row,col-1)==1))
        if (FinalCluster(row-1,col-1)==1)
            True=1;
        end
    end
end

%%%%%%%%%%%%%End Corner points%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%Left Side%%%%%%%%%%%%%%%%%%%%%%%

if (row<m &&  row>1 && col==1)
    if ((FinalCluster(row-1,col)==1) || (FinalCluster(row,col+1)==1))
        if (FinalCluster(row-1,col+1)==1)
            True=1;
        end
    end
        if ((FinalCluster(row,col+1)==1) || (FinalCluster(row+1,col)==1))
        if (FinalCluster(row+1,col+1)==1)
            True=1;
        end
    end
end
%%%%%%%%%%%%End Left Side%%%%%%%%%%%%%%%%%

%%%%%%%%%%Right Side%%%%%%%%%%%%%%%%%%%%%%%

if (row<m &&  row>1 && col==m)
    if ((FinalCluster(row-1,col)==1) || (FinalCluster(row,col-1)==1))
        if (FinalCluster(row-1,col-1)==1)
            True=1;
        end
    end
        if ((FinalCluster(row,col-1)==1) || (FinalCluster(row+1,col)==1))
        if (FinalCluster(row+1,col-1)==1)
            True=1;
        end
    end
end
%%%%%%%%%%%% End Right  Side%%%%%%%%%%%%%%%%%





%%%%%%%%%%Top Side%%%%%%%%%%%%%%%%%%%%%%%
if (col<n &&  col>1 && row==1)
    if ((FinalCluster(row,col-1)==1) || (FinalCluster(row+1,col)==1))
        if (FinalCluster(row+11,col-1)==1)
            True=1;
        end
    end
        if ((FinalCluster(row,col+1)==1) || (FinalCluster(row+1,col)==1))
        if (FinalCluster(row+1,col+1)==1)
            True=1;
        end
    end
end
%%%%%%%%%%End Top Side%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%Top Side%%%%%%%%%%%%%%%%%%%%%%%
if (col<n &&  col>1 && row==1)
    if ((FinalCluster(row,col-1)==1) || (FinalCluster(row+1,col)==1))
        if (FinalCluster(row+1,col-1)==1)
            True=1;
        end
    end
        if ((FinalCluster(row,col+1)==1) || (FinalCluster(row+1,col)==1))
        if (FinalCluster(row+1,col+1)==1)
            True=1;
        end
    end
end
%%%%%%%%%%End Top Side%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%Bottom Side%%%%%%%%%%%%%%%%%%%%%%%
if (col<n &&  col>1 && row==m)
    if ((FinalCluster(row,col-1)==1) || (FinalCluster(row-1,col)==1))
        if (FinalCluster(row-1,col-1)==1)
            True=1;
        end
    end
        if ((FinalCluster(row,col+1)==1) || (FinalCluster(row-1,col)==1))
        if (FinalCluster(row-1,col+1)==1)
            True=1;
        end
    end
end

%%%%%%%%%% End Bottom Side%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%Middle %%%%%%%%%%%%%%%%%%%%%%%
if (col<n &&  col>1 && row< m && row>1)
    if ((FinalCluster(row-1,col)==1) || (FinalCluster(row,col+1)==1))
        if (FinalCluster(row-1,col+1)==1)
            True=1;
        end
    end
    if ((FinalCluster(row,col+1)==1) || (FinalCluster(row+1,col)==1))
        if (FinalCluster(row+1,col+1)==1)
            True=1;
        end
    end
    if ((FinalCluster(row+1,col)==1) || (FinalCluster(row,col-1)==1))
        if (FinalCluster(row+1,col-1)==1)
            True=1;
        end
    end
    if ((FinalCluster(row,col-1)==1) || (FinalCluster(row-1,col)==1))
        if (FinalCluster(row-1,col-1)==1)
            True=1;
        end
    end
end

%%%%%%%%%% End Bottom Side%%%%%%%%%%%%%%%%%%%%%%%
