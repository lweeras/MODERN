function [True,CL1cell,CL2cell] = get_CompareList(List1,List2,m,n)
CL1cell=[]; CL2cell=[];
[p,~]=size(List1);
[q,~]=size(List2);
True =0;

for i=1:p
    Cell1=List1(i,1:2);
    if((Cell1(2)-1)~=0)
        LN1=[Cell1(1),Cell1(2)-1];
    else
        LN1=[0,0];
    end
    if((Cell1(2)+1)~=n+1)
        RN1=[Cell1(1),Cell1(2)+1];
    else
        RN1=[0,0];
    end
    if((Cell1(1)-1)~=0)
        TN1=[Cell1(1)-1,Cell1(2)];
    else
        TN1=[0,0];
    end
    if((Cell1(1)+1)~=m+1)
        BN1=[Cell1(1)+1,Cell1(2)];
    else
        BN1=[0,0];
    end
    [LN1 RN1 TN1 BN1];
    for j=1:q
        if ((List2(j,1)==LN1(1) && List2(j,2)==LN1(2)) || (List2(j,1)==RN1(1) && List2(j,2)==RN1(2))...
                || (List2(j,1)==TN1(1) && List2(j,2)==TN1(2)) || (List2(j,1)==BN1(1) && List2(j,2)==BN1(2))...
                ||(List2(j,1)==List1(i,1)) && (List2(j,2)==List1(i,2)) )
                     True=1;
            CL1cell=List1(i,:);
            CL2cell=List2(j,:);
            break
        end
        
    end
    if (True==1)
        break
    end
end



