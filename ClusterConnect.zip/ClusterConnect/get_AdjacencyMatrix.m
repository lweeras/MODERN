function True= get_AdjacencyMatrix ( FinalCluster,m,n)
for p=1:m
    for q=1:n
        if (FinalCluster(p,q)>0)
            FinalClusterOne(p,q)=1;
        end
    end
end

% AdjacencyMatrix=[];
% True=0;
% for k=1:m
%     for l=1:n
%         row=k;
%         col=l;
%         
%         Neighbours=zeros(m,n);
%         if(row>1)
%             Neighbours(row-1,col)=FinalCluster(row-1,col);
%         end
%         if(row<m)
%             Neighbours(row+1,col)=FinalCluster(row+1,col);
%         end
%         if (col>1)
%             Neighbours(row,col-1)=FinalCluster(row,col-1);
%         end
%         if(col<n)
%             Neighbours(row,col+1)=FinalCluster(row,col+1);
%         end
%         Neighbours; Adjacency=[];
%         for i=1:m
%             for j=1:n
%                 Adjacency=[Adjacency, Neighbours(i,j)];
%             end
%         end
%         AdjacencyMatrix=[AdjacencyMatrix;Adjacency];
%     end
% end
% AdjacencyMatrix;
% 
% 
% %AdjacencyMatrix=AdjacencyMatrix';
% NonConnectedCell=zeros(m,n);
% sum(AdjacencyMatrix); % If a cell is not connected the sum will be zero
% % Need to check connectivity only for slected cells in FinalCluster
% AdjacencyMatrix=AdjacencyMatrix';
% Connectedornot=sum(AdjacencyMatrix);
% for i=1: row
%     for j=1:col
% 
%         if (FinalCluster(i,j)~=0)
%             if (Connectedornot((i-1)*col+j)==0)
%                 NonConnectedCell(i,j)=10;
%             end
%         end
%     end
% end
% NonConnectedCell; % Matrix identfies the unconnected cells in FinalCluster
% 
% if (sum(sum(NonConnectedCell)~=0))
%     True=1;
% end
True=0;
visited=zeros(m,n);%make all nodes unvisited
for i=2:m-1
    for j=2:n-1
        if (FinalCluster(i,j)>0)
            visited(i,j)=0; % mark (i,j) as visited
  
            
            visited= get_traverse(i,j, visited ,FinalCluster,m,n);

            
            
            
            if ((sum(sum(visited)))~=(sum(sum(FinalClusterOne))))
           
                True=1;
            end
            
%             if (FinalCluster(i-1,j)>0)
%                 
%                 if (visited(i-1,j)==0)
%                     visited= get_traverse(i-1,j, visited ,FinalCluster);
%                 end
%             end
%             if (FinalCluster(i+1,j)>0)
%                 
%                 if (visited(i+1,j)==0)
%                     visited= get_traverse(i+1,j, visited ,FinalCluster);
%                 end
%             end
%             if (FinalCluster(i,j-1)>0)
%                 
%                 if (visited(i,j-1)==0)
%                     visited= get_traverse(i,j-1, visited ,FinalCluster );
%                 end
%             end
%             if (FinalCluster(i,j+1)>0)
%                 
%                 if (visited(i,j+1)==0)
%                     visited= get_traverse(i,j+1, visited ,FinalCluster);
%                 end
%             end
        end
        if (True==1)
            break
            
        end
    end
    if (True==1)
        break
        
    end
end
% visited=zeros(m,n); 
% True=0;
% for i=2:m-1
%     for j=2:n-1
%         
%         if (FinalCluster(i,j)>0)
%             visited(i,j)=1; % mark (i,j) as visited
%             ADJ=[];
%             if (FinalCluster(i-1,j)==1)
%                 ADJ=[ADJ,i-1,j];
%                 if (visited(i,j)==0)
%                     visited(i,j)=1;
%                 end
%             end
%             if (FinalCluster(i+1,j)==1)
%                 ADJ=[ADJ,i+1,j];
%                 if (visited(i,j)==0)
%                     visited(i,j)=1;
%                 end
%             end
%             if (FinalCluster(i,j-1)==1)
%                 ADJ=[ADJ,i,j-1];
%                 if (visited(i,j)==0)
%                     visited(i,j)=1;
%                 end
%             end
%             if (FinalCluster(i,j+1)==1)
%                 ADJ=[ADJ,i,j+1];
%                 if (visited(i,j)==0)
%                     visited(i,j)=1;
%                 end
%             end
%             
%             % if (FinalCluster(i-1,j)>0 || FinalCluster(i+1,j)>0 || FinalCluster(i,j-1)>0 || FinalCluster(i,j+1)>0)
%             %      visited(i,j)=1;
%             
%             % end
%             
%         end
%     end
% end

% for i=1:m
%     for j=1:n
%         if (FinalCluster(i,j)>0)
%             FinalCluster(i,j)=1;
%         end
%     end
% end
% 
% if ((sum(sum(visited)))==(sum(sum(FinalCluster))))
%     'good'
% True=1;
% end
dlmwrite('C:\CompactConnect2020\visited.txt',visited,'delimiter','\t');
