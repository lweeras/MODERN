function [Rank,Individual]=Get_Rank(AllSpe,NumSpe,Path,m,n)
Path;
Path=Path';
AllSpe;
[L,~]=size(Path);
AllExtraCoverage=[]; Individual=[];
for k=1:NumSpe
    ExtraCoverage=[]; ind=0;
    
    for p=0:(L/2)-1
        for i=1:m
            for j=1:n
                
                if (Path(2*p+1)==i && Path(2*p+2)==j )
                    Path(2*p+1);
                    Path(2*p+2);
                    % clusterData(i,j)=1; % Add Coridors to original clusters
                    val=AllSpe(i,j,k);
                    ExtraCoverage=[ExtraCoverage,val];
                    ind=ind+AllSpe(i,j,k);
                end
            end
            
        end
          ExtraCoverage;
    end
    AllExtraCoverage=[AllExtraCoverage;(ExtraCoverage)];
    Individual=[Individual,ind];
end
 AllExtraCoverage;
% size(AllExtraCoverage)
 Rank=sum(AllExtraCoverage); % coverage of individual cell
 Rank=sum(Rank); % the total coverage
%  if ((L/4)==1) % If l/2=1 means we need only one cell to connection. So we need to remove the double counting
%      Rank=Rank/2;
%  end
% Individual
% sum(Individual)
 