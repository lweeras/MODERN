
function [MergeCluster,clusterData]=Get_CombinedSystem(BestPath,clus1,clus2,MultiData,m,n,NumClu,clusterData)
BestPath=BestPath';
[L,~]=size(BestPath);
MergeCluster=[];
for i=1:NumClu
    if (i==clus1 )
        MultiData(:,:,i);
        MergeCluster=MultiData(:,:,i); % Add Clust 1 data to  MergeCluster
        
    end
end
MergeCluster;
for j=1:NumClu
    if (j==clus2)
        for k=1:m
            for l=1:n
                if ((MultiData(k,l,j)==1))
                    MergeCluster(k,l)=1; % Add Clust 2 data to  MergeCluster
                end
            end
        end
    end
end
MergeCluster;


for p=0:(L/2)-1
    for i=1:m
        for j=1:n
          
            if (BestPath(2*p+1)==i && BestPath(2*p+2)==j )
%                 BestPath(2*p+1)
%                 BestPath(2*p+2)
                MergeCluster(i,j)=1;
                clusterData(i,j)=1;
            end
        end
        
    end
    
end
MergeCluster;
UpdateMultiData=[]; % contains data that do not contain in Clus1 and clus 2


MergeCluster;
clusterData;

