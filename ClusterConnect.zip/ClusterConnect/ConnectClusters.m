clc
clear

%Clu1=load('cluster1.txt');
%Clu2=load('cluster2.txt');
%Clu3=load('cluster3.txt');;
clusterData=load('clusterData.txt')
% s1=load('s1.txt');
% s2=load('s2.txt');
% s3=load('s3.txt');
[m,n]=size(clusterData);
Label=1;
k=1;
NumClu=2;
Data=[];
    for i=1:m
        for j=1:n
            if (clusterData(i,j)==1)
                clusterData(i,j)=0;
 
            end
            
        end
    end
    clusterData;
for p=1:NumClu
    CurrentCluster=zeros(m,n);
    for i=1:m
        for j=1:n
            if (clusterData(i,j)==p+1)
                CurrentCluster(i,j)=1;
 
            end
            
        end
    end
    Data=[Data;CurrentCluster];
end
Data;
%Data=[Clu1;Clu2;Clu3]
for p=1:NumClu
    CurrentClu=Data((p-1)*n+1:p*n,:);
    MultiData(:,:,p)=CurrentClu;
end
MultiData;
while (NumClu~=1)
    for p=1:NumClu
        CurrentClu=Data((p-1)*n+1:p*n,:);
        MultiData(:,:,p)=CurrentClu;
    end
    OldData=MultiData;
    MultiData;
    Label=1;
    %[clus1,clus2,AllList,CL1cell,CL2cel2,LevelSize,Label] = get_OneClucter(MultiData, m,n,Label,NumClu);
    [clus1,clus2,AllList,CL1cell,CL2cel2,LevelSize,Label]=To_JoinClucters(MultiData, m,n,Label,NumClu)
     %[AlterPath,LevelSize,Label]=To_JoinCluctersAlternatives(MultiData, m,n,Label,NumClu)
    %CL1cell meeting place of the first cluster with the cluster number and
    %level
    %CL2cell meeting place of the second cluster with the cluster number and
    %level
    %AllList Need tp trace back to get the paths
%   dlmwrite('C:\CompactConnect2020\AllList.txt',AllList,'delimiter','\t');    
     [Connecter1,Connecter2,MultiData]=get_Coridors(clus1,clus2,AllList,CL1cell,CL2cel2,LevelSize,NumClu,Label,MultiData) ;
     Connecter1,Connecter2
       MergeCluster=[];
    for i=1:NumClu
        if (i==clus1 )
            MergeCluster=MultiData(:,:,i);
            
        end
    end
    MergeCluster;
    for j=1:NumClu
        if (j==clus2)
            for k=1:m
                for l=1:n
                    if ((MultiData(k,l,j)==1))
                        MergeCluster(k,l)=1;
                       end
                end
            end
        end
    end
    MergeCluster;
    UpdateMultiData=[MergeCluster];
    for i=1:NumClu
        if(i ~=clus1 && i~=clus2)
            UpdateMultiData=[UpdateMultiData;OldData(:,:,i)];
        end
    end
    Label=1;
    NumClu=NumClu-1;
    Data=UpdateMultiData;
end
MergeCluster;
clusterData;
for i=1:m
    for j=1:n
        if (clusterData(i,j)==0 && MergeCluster(i,j)==1)
            clusterData(i,j)=1;
        end
    end
end
MergeCluster
clusterData
dlmwrite('C:\CompactConnect2020\ClustermultiData.txt',clusterData,'delimiter','\t');    
dlmwrite('C:\CompactConnect2020\multiData.txt',MergeCluster,'delimiter','\t');