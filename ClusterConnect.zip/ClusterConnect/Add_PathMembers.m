function FinalPath= Add_PathMembers(LevelINeighbours,OldPath,Label,LevelIAdjacancies)
% This code take cares of the Level 1
OldPath;
t=1; [Num_neigh, ~]=size(OldPath);
Growpath=OldPath;
FinalPath=[];
while(t<=Num_neigh)
    Neighbours=LevelINeighbours;
    Pointer=Growpath(t,3:4);
    Adjacancies = get_BDCellForPath2(Neighbours,Pointer);
    [Num_Adj,~]=size(Adjacancies);
    TempGrowpath=zeros(1,2*((Label-1)));
    for k=1:Num_Adj
        TempGrowpath(:,1:2)=Adjacancies(k,1:2);
        Growpath(t,1:2)=Adjacancies(k,1:2);
       % OldPath=[OldPath;Growpath(t,:)]
        FinalPath=[FinalPath;Growpath(t,:)];
        TempGrowpath=zeros(1,2*((Label-1)));
    end
   % Growpath;
    t=t+1;
   end
FinalPath;
