function [CL1cell,CL2cell] = get_BDCellForPath(List1,List2,Cell1,Cell2)
m=length(List1);CL1cell=[]; CL2cell=[];
n=length(List2);
LN1=[Cell1(1),Cell1(2)-1];RN1=[Cell1(1),Cell1(2)+1];
TN1=[Cell1(1)-1,Cell1(2)];BN1=[Cell1(1)+1,Cell1(2)];
[LN1 TN1 RN1 BN1];
%'Now check'
%Cell2
LN2=[Cell2(1),Cell2(2)-1];RN2=[Cell2(1),Cell2(2)+1];
TN2=[Cell2(1)-1,Cell2(2)];BN2=[Cell2(1)+1,Cell2(2)];
% 'N1'
% [LN1,RN1,BN1,TN1]
% 'N2'
% [LN2,RN2,BN2,TN2]
 if (sum(Cell1)~=0)
for i=1:m
    if ((List1(i,1)==LN1(1) && List1(i,2)==LN1(2)))
        True1=1;
        CL1cell=List1(i,:);
        break
    end
    if ((List1(i,1)==RN1(1) && List1(i,2)==RN1(2)))
        True1=1;
        CL1cell=List1(i,:);
        break
    end
    if ((List1(i,1)==TN1(1) && List1(i,2)==TN1(2)))
        True1=1;
        CL1cell=List1(i,:);
        break
    end
    if ((List1(i,1)==BN1(1) && List1(i,2)==BN1(2)))
        True1=1;
        CL1cell=List1(i,:);
        break
    end
end
 end
if (sum(Cell2)~=0)
for i=1:n
    if ((List2(i,1)==LN2(1) && List2(i,2)==LN2(2)))
        True1=1;
        CL2cell=List2(i,:);
        break
    end
    if ((List2(i,1)==RN2(1) && List2(i,2)==RN2(2)))
        True1=1;
        CL2cell=List2(i,:);
        break
    end
    if ((List2(i,1)==TN2(1) && List2(i,2)==TN2(2)))
        True1=1;
        CL2cell=List2(i,:);
        break
    end
    if ((List2(i,1)==BN2(1) && List2(i,2)==BN2(2)))
        True1=1;
        CL2cell=List2(i,:);
        break
    end
end
end