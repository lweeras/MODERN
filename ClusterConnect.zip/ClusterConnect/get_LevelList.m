function OnlyMembers=get_LevelList(List,Label,m,LevelNum)
LevelSize=[];
for i=Label:-1:1
    Neighbours=[];
    for k=1:m % m is the lize of the list to find paths
        CurrentList=List(k,:) ;
        if (CurrentList(4)==i) % neighbours at the current level
            Neighbours=[Neighbours;CurrentList];
        end
    end
    [L,~]=size(Neighbours);
    LevelSize=[LevelSize,L];
end
MaxLevelMembers=max(LevelSize);

for p=Label:-1:1
    p;
    LevelList(:,:,p)=zeros(MaxLevelMembers,4);
    Neighbours=[];
    for k=1:m % m is the lize of the list to find paths
        CurrentList=List(k,:) ;
        if (CurrentList(4)==p) % neighbours at the current level
            Neighbours=[Neighbours;CurrentList];
        end
    end
    [L,~]=size(Neighbours);
    LevelList(1:L,:,p)=Neighbours;
end
LevelList;RequiredList=[];
for p=Label:-1:1
    if (p==LevelNum)
        RequiredList=LevelList(:,:,p);
    end
end
[L,~]=size(RequiredList);
OnlyMembers=[];
for k=1:L
    currentrow=RequiredList(k,:);
    if (sum(currentrow)~=0)
        OnlyMembers=[OnlyMembers;currentrow];
    end
end
