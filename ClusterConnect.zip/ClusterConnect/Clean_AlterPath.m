function AlterPath=Clean_AlterPath(AlterPath,MeetingLevel)
MeetingLevel=MeetingLevel-1;
[m,~]=size(AlterPath);
EqualLevel=[];
UnequalLevel=[];
% for  counter=0:(m/2)-1
%         CL1cell=AlterPath(2*counter+1,:);% Intersection of First Clsuter
%         CL2cel2=AlterPath(2*counter+2,:); % Intersection of Second Clsuter
%         if ((CL1cell(4)==CL2cel2(4)))
%             EqualLevel=[EqualLevel;CL1cell;CL2cel2];
%         else
%             UnequalLevel=[UnequalLevel;CL1cell;CL2cel2];
%         end
% end
%
% [m1,~]=size(EqualLevel);
% [m2,~]=size(UnequalLevel);
%
% if (m2>0)
%     AlterPath=UnequalLevel;
% end

AlterPathone=[];
for  counter=0:(m/2)-1
    CL1cell=AlterPath(2*counter+1,:);% Intersection of First Clsuter
    CL2cel2=AlterPath(2*counter+2,:); % Intersection of Second Clsuter
    if ((CL1cell(4)==CL2cel2(4)))
        if (CL1cell(4)==1)
            AlterPathone=[AlterPathone; CL1cell;CL2cel2];
        else
            EqualLevel=[EqualLevel;CL1cell;CL2cel2];
        end
    else
        UnequalLevel=[UnequalLevel;CL1cell;CL2cel2];
    end
end
EqualLevel;
UnequalLevel;
AlterPathone;

[m1,~]=size(EqualLevel);
[m2,~]=size(UnequalLevel);
[m3,~]=size(AlterPathone);

Uniqueones=[];
for  counter=0:(m3/2)-1
    CL1cell=AlterPathone(2*counter+1,:);% Intersection of First Clsuter
    CL2cel2=AlterPathone(2*counter+2,:); % Intersection of Second Clsuter
    if (((CL1cell(1))== (CL2cel2(1))) && ((CL1cell(2))== (CL2cel2(2))))
        Uniqueones=[Uniqueones;CL1cell;CL2cel2];
    end
end
Uniqueones;
[m3,~]=size(Uniqueones);
if (m3>0)% Special for level 1
    AlterPath= Uniqueones;
elseif (m2>0)
    AlterPath=UnequalLevel;
end