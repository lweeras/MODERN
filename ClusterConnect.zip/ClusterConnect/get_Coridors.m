%function [Connecter1,Connecter2,OldMultiData]=get_Coridors(clus1,clus2,AllList,CL1cell,CL2cell,LevelSize,NumClu,Label,MultiData)
function [FinalPath,IndividualCoverage]=get_Coridors(clus1,clus2,AllList,CL1cell,CL2cell,LevelSize,NumClu,Label,MultiData,AllSpe,NumSpe,m,n)
Label;
OldMultiData=MultiData;
Successor1=[];
Successor2=[];UpdatedList=[];
Connecter1=[];Connecter2=[];
AllList;
for p=1:length(AllList) % Identify sucsessors for Clsu 1 and Clus 2
    ListEntry=AllList(p,:);
    if (ListEntry(4)~=Label(1))
        for k=1:NumClu
            if (ListEntry(3)==clus1)
                Successor1=[Successor1;ListEntry];
            end
        end
    end
    
    if (ListEntry(4)~=Label(2))
        for k=1:NumClu
            
            if (ListEntry(3)==clus2)
                Successor2=[Successor2;ListEntry];
            end
        end
    end
    
end

[~, iA] = uniquetol(Successor1, 'byrows', true);
Successor1=Successor1(sort(iA), :);
[~, iA] = uniquetol(Successor2, 'byrows', true);
Successor2=Successor2(sort(iA), :);
Successor1; % Clus 1 successors at Level Label-1
Successor2 ;% Clus 2 successors at Level Label-1

 [L1,~]= size(Successor1);
[L2,~]= size(Successor2);
UpdatedList;
OldMultiData(CL1cell(1),CL1cell(2),clus1)=1; % update poatio of the intersection for Clus 1
OldMultiData(CL2cell(1),CL2cell(2),clus2)=1; % update poatio of the intersection for Clus 2
Connecter1=[Connecter1,CL1cell(1),CL1cell(2)];
Connecter2=[Connecter2,CL2cell(1),CL2cell(2)];
Cell1=CL1cell;
Cell2=CL2cell;
Successor1;
Successor2;
%FinalPath1=get;_MultipleConnectors(Successor1,[2,4,1,4],Label(1),L1);% All path connecting CL1cell and clus1
FinalPath1=get_MultipleConnectors(Successor1,CL1cell,Label(1),L1);% All path connecting CL1cell and clus1
%FinalPath2=get_MultipleConnectors(Successor2,[3 4 2 3],Label(2),L2);% All path connecting CL2cell and clus2
FinalPath2=get_MultipleConnectors(Successor2,CL2cell,Label(2),L2);% All path connecting CL2cell and clus2
[FinalPath,IndividualCoverage]=To_CombinePath(FinalPath1,FinalPath2,AllSpe,NumSpe,m,n);
