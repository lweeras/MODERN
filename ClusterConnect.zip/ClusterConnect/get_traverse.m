function visited= get_traverse(i,j, visited ,FinalCluster,m,n)
visited(i,j)=1;
%m=16;n=16;
for k=2:m-1
    for l=2:n-1
        
        if((k==i-1 && l==j) || (k==i+1 && l==j) || (k==i && l==j-1) || (k==i && l==j+1))

            if (visited(k,l)==0 && FinalCluster(k,l)>0)
                visited= get_traverse(k,l, visited,FinalCluster,m,n );
            end
            % if (FinalCluster(i-1,j)>0)
            %
            %     if (visited(i-1,j)==0)
            %         visited= get_traverse(i-1,j, visited,FinalCluster );
            %     end
            % end
            % if (FinalCluster(i+1,j)>0)
            %
            %     if (visited(i+1,j)==0)
            %         visited=    get_traverse(i+1,j, visited,FinalCluster );
            %     end
            % end
            % if (FinalCluster(i,j-1)>0)
            %
            %     if (visited(i,j-1)==0)
            %         visited=   get_traverse(i,j-1, visited,FinalCluster );
            %     end
            % end
            % if (FinalCluster(i,j+1)>0)
            %
            %     if (visited(i,j+1)==0)
            %         visited=    get_traverse(i,j+1, visited,FinalCluster );
            %     end
            % end
        end
    end
end
visited;

% Begin First 
%    define visited array
%       for all vertices u in the graph, do
%          make all nodes unvisited
%          traverse(u, visited)
%          if any unvisited node is still remaining, then
%             return false
%       done
%    return true
% End

% Begin
%    mark u as visited
%    for all vertex v, if it is adjacent with u, do
%       if v is not visited, then
%          traverse(v, visited)
%    done
% End