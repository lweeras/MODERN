function FinalPath=get_MultipleConnectors(Successor,Cell,Label,L)
% Very tricky. This code finds all possible paths starting from Cell
List=Cell;
Cell;
if(Cell(4)==1)
    FinalPath=Cell(1:2);
else
    
    for p=Label-1:-1:1 %To find the connection
        
        CurrentList=[];
        for i=1:L % For Clus 2
            currentrow=Successor(i,:);
            if (currentrow(4)==p )
                CurrentList=[CurrentList;currentrow];
            end
        end
        CurrentList;
        % Identify the list in the level p
        t=1;NumPoints=1; True=0;
        while (t<=NumPoints)% AddAll
            
            Cell=List(t,:);
            if (Cell(4)~=1)
                
                Adjacancies = get_BDCellForPath2(CurrentList,Cell) ;% Find all neighbours of Cell
                %Need a if condition to reove duplicates
                List=[List;Adjacancies]; % Add all eighbours of Cell to lists
                [~, iA] = uniquetol(List, 'byrows', true);
                List=List(sort(iA), :);
                [NumAdj,~]=size(Adjacancies); % Number of nei
                [NumPoints,~]=size(List) ;
                % NumPoints=NumPoints+NumAdj;
                t=t+1;% find the neighbours of the next
                
            else
                True=1 ;
            end
            if (True==1)
                break
            end
        end
        
    end
    Label;
    [m,~]=size(List);
    List;
    FinalPath=[];
    SizeNeigh=1;Neighbours=[];
    Pointer=List(1,:);
    Neighbours=get_LevelList(List,Label-1,m,Label-2); % We start to grow the paths from level Label-2
    LevelIAdjacancies = get_BDCellForPath2(Neighbours,Pointer);% Find adjancies of the starting point
    [StartLevel,~]=size(LevelIAdjacancies);
    Growpath=zeros(StartLevel,2*((Label-1)));
    for q=1:StartLevel
        Growpath(q,end-1:end)=List(1,1:2); % This for loops for adding the root
    end
    Growpath;
    OldPath=[];
    Label;
    for i=Label-2:-2:1
        
        LevelINeighbours=get_LevelList(List,Label-1,m,i);% Neighbour of Level i
        LevelIAdjacancies = get_BDCellForPath2( LevelINeighbours,Pointer);
        [LevelI_neigh,~]=size(LevelIAdjacancies);
        
        if(LevelI_neigh==0 || i==1)
            if(i==1)
                OldPath=Growpath;
            end
            FinalPath= Add_PathMembers(LevelINeighbours,OldPath,Label,LevelINeighbours);
        else
            Growpath(:,2*i-1:2*i)=LevelIAdjacancies(:,1:2);
            t=1; Num_neigh=1;
            %GrowpathUnmodified=Growpath;
            while(t<=LevelI_neigh)
                Neighbours=get_LevelList(List,Label-1,m,i-1);%% Neighbour of Level i-1
                Pointer=LevelIAdjacancies(t,:);
                Adjacancies = get_BDCellForPath2(Neighbours,Pointer);
                [Num_Adj,~]=size(Adjacancies);
                TempGrowpath=zeros(1,2*((Label-1)));
                for k=1:Num_Adj
                    TempGrowpath(:,2*(i-1)-1:2*(i-1))=Adjacancies(k,1:2);
                    Growpath(t,2*(i-1)-1:2*(i-1))=Adjacancies(k,1:2);
                    OldPath=[OldPath;Growpath(t,:)];
                    TempGrowpath=zeros(1,2*((Label-1)));
                end
                Growpath;
                t=t+1;
                Num_neigh=Num_neigh+Num_Adj;
            end
            %end
            FinalPath=OldPath;
        end
    end
end

FinalPath;




