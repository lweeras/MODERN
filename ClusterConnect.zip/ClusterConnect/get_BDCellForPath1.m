function [CL1cell] = get_BDCellForPath1(List1,Cell1)
[m,~]=size(List1);CL1cell=[];

LN1=[Cell1(1),Cell1(2)-1];RN1=[Cell1(1),Cell1(2)+1];
TN1=[Cell1(1)-1,Cell1(2)];BN1=[Cell1(1)+1,Cell1(2)];
[LN1 TN1 RN1 BN1];

% if (sum(Cell1)~=0)
%     for i=1:m
%         if ((List1(i,1)==LN1(1) && List1(i,2)==LN1(2)))
%             True1=1;
%             CL1cell=List1(i,:);
%             break
%         end
%         if ((List1(i,1)==RN1(1) && List1(i,2)==RN1(2)))
%             True1=1;
%             CL1cell=List1(i,:);
%             break
%         end
%         if ((List1(i,1)==TN1(1) && List1(i,2)==TN1(2)))
%             True1=1;
%             CL1cell=List1(i,:);
%             break
%         end
%         if ((List1(i,1)==BN1(1) && List1(i,2)==BN1(2)))
%             True1=1;
%             CL1cell=List1(i,:);
%             break
%         end
%     end
% end
if (sum(Cell1)~=0)
    for i=1:m
        if ((List1(i,1)==LN1(1) && List1(i,2)==LN1(2)))
            True1=1;
            CL1cell=[CL1cell;List1(i,:)];
           % break
        end
        if ((List1(i,1)==RN1(1) && List1(i,2)==RN1(2)))
            True1=1;
            CL1cell=[CL1cell;List1(i,:)];
           % break
        end
        if ((List1(i,1)==TN1(1) && List1(i,2)==TN1(2)))
            True1=1;
            CL1cell=[CL1cell;List1(i,:)];
          %  break
        end
        if ((List1(i,1)==BN1(1) && List1(i,2)==BN1(2)))
            True1=1;
            CL1cell=[CL1cell;List1(i,:)];
          %  break
        end
    end
end
