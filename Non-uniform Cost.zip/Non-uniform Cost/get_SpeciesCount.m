function [speciescount,Occurrence]=get_SpeciesCount(Species,MultiData,NumSpe,m,n)
for p=1:NumSpe
    CurrentSpe=Species((p-1)*n+1:p*n,:);% % Identify the species in each cluster
    AllSpe(:,:,p)=CurrentSpe; % Add them to a multi-array
end
AllSpe; %This multiarray provides the species in each cluster for type
speciescount=[]; % This array provides the total number of occurrences of each species in the cluster.
Occurrence=[]; % This array provides the total number of occurrences of each species in the inital system.
for p=1:NumSpe
    spcount=0; occ=0;
    for i=1:m
        for j=1:n
            if (AllSpe(i,j,p)>0 )
                occ=occ+AllSpe(i,j,p);
            end
             
            %for k=1:NumClu
                if (AllSpe(i,j,p)>0 && MultiData(i,j)>=1)
                    spcount=spcount+AllSpe(i,j,p);
                end
                
            %end
        end
    end
   Occurrence=[Occurrence,occ];
    speciescount=[speciescount,spcount];
end
speciescount;
Occurrence;
