function const = get_const(row,col,species)

const=[];
for i=1:row
    for j=1:col
        (i-1)*col+j;
        const=[const, species((i-1)*col+j)];
    end
end

