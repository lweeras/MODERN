function adj_const = get_block1(row,col,ADJlist)

m = row;
n = col;
numVar = m*n;

cor = 8;                 
edg = 6*(m-2) + 6*(n-2);    
int = 4*(m-2)*(n-2);        
numAdj = (cor + edg + int);


first_block = [];
for i = 1:numVar
    Row = zeros(1,numVar);
    Row(i) = -1;
    current_list = ADJlist(i,:);
    numNonZero = sum(current_list(1,2:5)~=0);
    for j = 1:numNonZero
        first_block=[first_block,Row];
    end
end
T = transpose(reshape(first_block,numVar,numAdj));
I = eye(numAdj);
Z = zeros(numAdj,1);
adj_const = [T I Z];