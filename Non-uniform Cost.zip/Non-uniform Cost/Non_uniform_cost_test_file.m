clc
clear;

Species=load('Species_Coverage_400km.txt');
cost=load('Cost.txt');
n=20;
m=20;
NumSpe=30;

%coverage1 = [15;1;6;1;2;17;14;7;20;1;9;8;16;16;4;10;9;13;15;16;6;14;14;4;3;10;20;7;12;5];
%coverage2 = [16;6;11;14;18;20;11;3;3;6;17;6;17;5;19;7;4;6;13;10;8;17;12;11;19;6;16;16;8;12];
%coverage3 = [20;11;3;7;4;8;12;14;12;22;13;24;16;24;7;17;8;17;18;2;7;6;17;22;9;20;17;1;16;10];

B=219;

%%%%%%%%%Input parameters are above%%%%%%%%%%%%%%%%%%%%%%%%
size(Species);
num_adjacency = (8+6*(m+n-4)+4*(m-2)*(n-2));
numVar=n*m;
ADJlist = get_ADJlist(n,m);
UB=[ones(1,numVar),inf(1,num_adjacency)];
LB=[zeros(1,numVar),zeros(1,num_adjacency)];

constraint=[];
for p=1:NumSpe
    CurrentSpe=Species((p-1)*n+1:p*n,:);
    Spconst = get_const(n,m,CurrentSpe);  
    constraint=[constraint;Spconst]; 
end
size(constraint);

for i=1:n
    for j=1:m
        costvector((i-1)*m+j)=cost(j,i); 
    end
end

adj_const1 = get_block1(n,m,ADJlist); % y_ij <= x_i
size(adj_const1);
adj_const2 = get_block2(n,m,ADJlist); % y_ij <= x_j
size(adj_const2);
adj_const3 = get_block3(n,m,ADJlist); % y_ij >= x_i + x_j - 1
size(adj_const3);

ConstraintMatrix=[-constraint,zeros(NumSpe,num_adjacency);... 
    adj_const1(:,1:end-1); 
    adj_const2(:,1:end-1); 
    adj_const3(:,1:end-1); 
    costvector, zeros(1,num_adjacency)];

RHS=[-coverage;...      
    adj_const1(:,end);  
    adj_const2(:,end); 
    adj_const3(:,end);
    B]'; 

% Dinkelbach Algorithm 
tic
fval = 1;
Lambda=1.5;
it_count = 0;
while (fval > 10E-10)
    [x, fval] = intlinprog([Lambda*ones(1,numVar),-0.5*ones(1,num_adjacency)],[1:1:numVar], ConstraintMatrix, RHS,[],[], LB', UB',[]);% optimization
    fval
    top=sum(x(1:numVar));
    bottom=sum(x(numVar+1:end));
    newlambda=0.5*bottom/top;
    Lambda=newlambda
    it_count=it_count+1;
end

OptimalSelection=zeros(n,m);
for i=1:n
    for j=1:m
        if ((i-1)*m+j<=numVar)
            if (x((i-1)*m+j)>0.99)
                OptimalSelection(j,i)=1;
            end
        end
    end
end
OptimalSelection;
sum(sum(OptimalSelection));

for i = 1:n
    for j = 1:m
        if OptimalSelection(i,j)>0
            CostMat1(i,j) = cost(i,j);
        else
            CostMat1(i,j) = 0;
        end
    end
end

Cost1 = sum(sum(CostMat1));

[Newspeciescount,Occurrence]=get_SpeciesCount(Species,OptimalSelection,NumSpe,m,n);
Newspeciescount;


