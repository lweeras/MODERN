function adj_const3 = get_block3(row,col,ADJlist)

m = row;
n = col;
numVar = m*n;

cor = 8;                  
edg = 6*(m-2) + 6*(n-2);    
int = 4*(m-2)*(n-2);        
numAdj = (cor + edg + int);

third_block = [];
for i = 1:numVar
    Row1 = zeros(1,numVar);
    Row1(i) = 1;
    current_list = ADJlist(i,:);
    adjCells = nonzeros(current_list(1,2:5));
    for j = 1:length(adjCells)
        Row2 = zeros(1,numVar);
        Row2(adjCells(j)) = 1;
        third_block=[third_block,Row1+Row2];
    end
end
T = transpose(reshape(third_block,numVar,numAdj));
I = -eye(numAdj);
One = ones(numAdj,1);
adj_const3 = [T I One];
