function adj_const2 = get_block2(row,col,ADJlist)

m = row;
n = col;
numVar = m*n;

cor = 8;                  
edg = 6*(m-2) + 6*(n-2);    
int = 4*(m-2)*(n-2);       
numAdj = (cor + edg + int); 

second_block = [];
for i = 1:numVar
    current_list = ADJlist(i,:);
    adjCells = nonzeros(current_list(1,2:5));
    for j = 1:length(adjCells)
        Row = zeros(1,numVar);
        Row(adjCells(j)) = -1;
        second_block=[second_block,Row];
    end
end

T = transpose(reshape(second_block,numVar,numAdj));
I = eye(numAdj);
Z = zeros(numAdj,1);
adj_const2 = [T I Z];