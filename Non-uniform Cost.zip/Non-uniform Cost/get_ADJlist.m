function ADJlist= get_ADJlist(row,col)

m=row; % row
n=col; % column
get_adj(m,n);
NumVar=m*n;

AdjacencyList=[];
for i=1:NumVar
    list=zeros(1,5);
    list(1)=i;
    
    if (i==1) %(top left corner of matrix)
        
        list(3)=i+m;
        list(4)=i+1; 
        
    end
    if (i==m) %(bottom left corner of matrix)
        
        i;
        list(2)=m-1; 
        list(3)=2*m;  

    end
    if (i==(n-1)*m+1) %(top right corner of matrix)
        
        list(4)=(n-1)*m+2;
        list(5)=(n-2)*m+1; 
         
    end
    if (i==m*n) %(bottom right corner of matrix)

        list(2)= m*n-1; 
        list(5)=(n-1)*m;
        
    end
    if (i>1 && i<m) %(left side of matrix w/o corners)
        
        i;
        list(2)=i-1;
        list(3)=m+i;
        list(4)=i+1;
        
        
    end
    if (i>(n-1)*m+1 && i<NumVar) %(right side of matrix w/o corners)
        
        i;
        list(2)=i-1;
        list(4)=i+1;
        list(5)=i-m;
        
    end
    if (i>1 && mod(i,m)==1 && i<(n-1)*m) %(top of matrix w/o corners)
        
        i;
        list(3)=i+m;
        list(4)=i+1;
        list(5)=i-m;    
        
    end
    if (mod(i,m)==0 && i>m && i<NumVar) %(bottom of matrix w/o corners)
        
        i;
        list(2)=i-1;
        list(3)=i+m;
        list(5)=i-m;
        
    end
    if (mod(i,m)~=1 && mod(i,m)~=0 && i> (m+1) && i<(n-1)*m)  %(interior of matrix, no border cells)
        
        i;
        list(2)=i-1;
        list(3)=i+m;
        list(4)=i+1;
        list(5)=i-m; 
        
    end
    
    list;
    AdjacencyList=[AdjacencyList;list];
end

ADJlist = [AdjacencyList];